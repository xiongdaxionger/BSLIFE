const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    record:'none',
    cargo:'',
    selected:'selected',
    active:'',
    getinven:[],
    getpicklog:[],
    getinvlog: [],
    three:'',
    threecargo: 'none',
  },
  onLoad:function(){
    var that = this;
    var postData = {
      method: 'pos.cartweb.getinven',
      member_id: app.globalData.userInfo.userId,
      page:'1'
    };
    app.request(postData, function (e) {
      that.setData({
        getinven:e.list
      })
    }, function (msg, e) {
      
    }, true, false, true);
    
  },
  showCargo:function(){
    this.setData({
      record: 'none',
      cargo: '',
      threecargo: 'none',
      selected: 'selected',
      active: '',
      three:''
    })
  },
  showRecord:function(){
    var that = this;
    var param = {
      method: 'pos.cartweb.getpicklog',
      member_id: app.globalData.userInfo.userId,
      page: '1'
    }
    app.request(param, function (res) {
      that.setData({
        record: '',
        cargo: 'none',
        threecargo:'none',
        selected: '',
        active: 'selected',
        three:'',
        getpicklog: res.list
      })
    }, function (msgg, res) {

    }, true, false, true);
    
  },
  showInv:function(){
    var that = this;
    var param = {
      method: 'b2c.member.inventory_log',
      member_id: app.globalData.memberId,
      wx_pro_mid: app.globalData.memberId,
      page: '1'
    };
    app.request(param, function (e) {
      that.setData({
        selected: '',
        active: '',
        three: 'selected',
        record: 'none',
        cargo: 'none',
        threecargo: '',
        getinvlog: e.list
      })
    }, function (msg, e) {

    }, true, false, true);
  },
  tapGood: function (event) {
    var productId = event.currentTarget.dataset.productid;
    wx.navigateTo({
      url: '/pages/gooddetail/gooddetail?productID=' + productId,
    })
  },
})