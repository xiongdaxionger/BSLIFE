const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    markers: [],
    info:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    this.setData({
      info:options,
      markers: [{
        iconPath: "../../images/icon/dingwei.png",
        id: 1,
        latitude: options.lat,
        longitude: options.lnt,
        width: 30,
        height: 30
      }],
      
    })
  },
  callphone: function (e) {
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.id
    })
  },

})