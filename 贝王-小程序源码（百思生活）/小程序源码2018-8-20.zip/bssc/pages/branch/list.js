const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    branchList:[],
    lnt: '',
    lat: '',
    page:1,
    total:1,
    name:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          lnt: res.longitude,
          lat: res.latitude,
          page: 1,
        })
        that.getbranch(res);
      },
      fail:function(e){
        that.setData({
          page: '1',
        })
        that.getbranch(e);
      }
    })
    
  },
  // 获取门店列表
  getbranch:function(e){
    var that = this;
    var longitude = that.data.lnt;
    var latitude = that.data.lat;
    var name = that.data.name;
    var postData = {
      method: 'pos.store.store_list',
      page: that.data.page,
      name: name,
      lnt: longitude,
      lat: latitude
    };
    app.request(postData, function (e) {
      var branchList = e.data;
      if(that.data.page > 1){
        branchList = that.data.branchList.concat(e.data);
      }
      that.setData({
        branchList: branchList,
        total: e.pager.total
      })
    }, function (msg, e) {

    }, true, false, true);
  },
  // 打电话
  callphone:function(e){
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.id
    })
  },
  // 搜索
  seachconfirm:function(e){
    var name = {
      name: e.detail.value
    };
    this.setData({
      page:1,
      name: e.detail.value
    })
    this.getbranch(name);
  },
  seachcancel:function(){
    this.setData({
      page: 1,
      name: ''
    })
    this.getbranch();
  },
  scrolltolowe:function(e){
    if (this.data.page <= this.data.total){
      var page = parseFloat(this.data.page) + 1;
      var oldpage = parseFloat(this.data.page);
      var total = parseFloat(this.data.total);
      if (oldpage != total){
        this.setData({
          page: page,
        })
        this.getbranch();
      }
      
    }
  },
  // 地图页
  mapdetail:function(e){
    var lat = e.currentTarget.dataset.lat;
    var lnt = e.currentTarget.dataset.lnt;
    var phone = e.currentTarget.dataset.phone;
    var name = e.currentTarget.dataset.name;
    var opentime = e.currentTarget.dataset.opentime;
    var stroelogo = e.currentTarget.dataset.stroelogo;
    if (lat == '' || lat == null || lnt == '' || lnt == null){
      wx.showToast({
        title: '经纬度无效!',
        icon: 'none'
      })
      return false;
    }
    wx.navigateTo({
      url: './mapdetail?lat=' + lat + '&lnt=' + lnt + '&phone=' + phone + '&name=' + name + '&opentime=' + opentime + '&stroelogo=' + stroelogo,
    })
  },
  // 选择门店
  choosebranch:function(e){
    var id = e.currentTarget.dataset.id;
    var name = e.currentTarget.dataset.name;
    var addr = e.currentTarget.dataset.addr;
    const wxCurrPage = getCurrentPages();//获取当前页面的页面栈
    const wxPrevPage = wxCurrPage[wxCurrPage.length - 2];//获取上级页面的page对象
    if (wxPrevPage) {
      //修改上级页面的数据
      wxPrevPage.setData({
        selfproxy_id: id,
        selfproxy_name: name,
        selfproxy_addr: addr
      })
      wx.navigateBack({})
    }
  }

  
})