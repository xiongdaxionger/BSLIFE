// pages/sms_code_fetch.js

var app = null;
var stringUtil = null;

Page({
  data: {
    phoneNumber: null, //手机号
    code: null, //短信验证码

    nextEnable: false, //是否可以下一步

    count_down: false, //是否在倒计时
    second: 120, //当前倒计时秒数

    ///是否需要验证码
    showImageCode:false,

    ///图形验证码链接
    codeURL:'',

    ///图片验证码
    imageCodeURL:'',

    ///输入的图形验证码
    inputCode:null
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    this.setData({
      phoneNumber : options.phoneNumber,
    });
    this.data.showImageCode = options.codeURL == '' ? false : true
    this.data.codeURL = options.codeURL
    app = getApp();
    stringUtil = require("../../utils/string.js");

    this.startTimer();
  },
  onUnload: function () {
    // 页面关闭
    this.stopTimer();
    app = null;
    stringUtil = null;

  },

  // 联系客服
  tapService: function () {
app.getServicePhoneNumber(function(phone){
      wx.makePhoneCall({
        phoneNumber: phone
      })
    })
  },

  // 下一步
  next: function () {
    const data = this.data;
    if (!data.nextEnable)
      return;
    const phoneNumber = data.phoneNumber;
    const code = data.code;

    // 验证输入的短信验证码
    var params = {
      method: 'b2c.passport.get_vcode',
      uname: phoneNumber,
      'type': 'signup'
    };
    const that = this;
    app.request(params, function (data) {
      const vCode = data.vcode;
      if (vCode == code) {
        wx.redirectTo({
          url: '/pages/login/register?phoneNumber=' + phoneNumber + '&code=' + code
        })
      } else {
        wx.showModal({
          title: '输入的验证码有误',
          content: "",
          showCancel: false
        });
      }
    }, function () {

    }, true, true, true);
  },

  // 输入改变
  vcodeDidChange: function (event) {
    this.data.code = event.detail.value;
    this.changeEnable()
  },
  codeDidChange: function (event) {
    this.data.inputCode = event.detail.value;
  },
  changeEnable: function () {
    this.setData({
      nextEnable: this.data.code != null && this.data.code.length > 0
    });
  },

  // 获取验证码
  getCode: function () {
    if (!this.data.count_down) {
      const data = this.data;
      const phoneNumber = data.phoneNumber;

      if (this.data.showImageCode && this.data.inputCode == null) {

        wx.showModal({
          title: '请输入图形验证码',
          content: "",
          showCancel: false
        });
        return
      }

      var params = {
        method: 'b2c.passport.send_vcode_sms',
        uname: phoneNumber,
        'type': 'signup'
      };
      if (this.data.showImageCode) {
        params.sms_vcode = this.data.inputCode
      }
      const that = this;
      app.request(params, function (data) {
        wx.showModal({
          title: '验证码已发送，请注意查收',
          content: "",
          showCancel: false
        });

        that.startTimer();
      }, function () {
        if (that.data.showImageCode) {
          that.tapImageCode()
        }
      }, true, true, true);
    }
  },

  // 启动倒计时
  startTimer: function () {

    const that = this;
    that.setData({
      count_down: true,
      second: 120
    });

    var timer = setInterval(function () {
      var second = that.data.second;
      second--;
      if (second <= 0) {
        that.stopTimer();
      } else {
        that.setData({
          second: second
        })
      }
    }, 1000);
    this.data.timer = timer;
  },

  // 停止倒计时
  stopTimer: function () {
    var timer = this.data.timer;
    if (timer != null) {
      clearInterval(timer);
      if (this.data.showImageCode) {
        this.setData({
          showImageCode: true
        })
        this.tapImageCode()
      }
      this.setData({
        timer: null,
        count_down: false
      })
    }
  },
  ///变更图形验证码
  tapImageCode:function() {
    let imageCodeURL = this.data.codeURL + "?t=" + new Date().getTime()

    this.getImageCodeRequest(imageCodeURL)
  },
  ///获取图片验证码
  getImageCodeRequest: function (url) {
    const that = this;

    wx.request({
      url: url,
      header: { "Content-Type": "application/json" },
      responseType: 'arraybuffer',
      dataType: "json",
      method: "GET",
      success: function (res) {
        let base64 = wx.arrayBufferToBase64(res.data)
        console.log('base64', base64)

        let src = 'data:image/jpg;base64,' + base64
        console.log('src', src)
        that.setData({
          showImageCode: true,
          imageCodeURL: src
        })
      }
    })
  },
})