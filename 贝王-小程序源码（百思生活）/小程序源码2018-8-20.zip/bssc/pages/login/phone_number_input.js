// pages/phone_number_input.js
var app = null;
var stringUtil = null;
var httpRequest = require('../../utils/httpRequest.js');
Page({
  data:{
    phoneNumber:null, //手机号

    showImageCode:false, ///是否显示图形验证码

    codeURL: httpRequest.getDomain() +'wap2/index-gen_vcode-LOGINVCODE.html',///验证码前置链接

    imageCodeURL:'',///图形验证码链接

    inputCode:null,///输入的图形验证码

    nextEnable: false, //是否可以下一步

  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    app = getApp();
    stringUtil = require("../../utils/string.js");
    this.getRegisterNeedInfo();
  },
  onUnload:function(){
    // 页面关闭
    app = null;
    stringUtil = null;
  },

  // 联系客服
  tapService:function(){
    app.getServicePhoneNumber(function(phone){
      wx.makePhoneCall({
        phoneNumber: phone
      })
    })
  },

  // 下一步
  next:function(){
     const data = this.data;
     if (!data.nextEnable)
       return;
      const phoneNumber = data.phoneNumber;
      if (phoneNumber == null || phoneNumber.length == 0) {
        wx.showModal({
          title: '请输入手机号',
          content: "",
          showCancel: false
        });
        return
      }
      if (!stringUtil.isMobileNumber(phoneNumber)) {
        wx.showModal({
          title: '请输入有效手机号',
          content: "",
          showCancel: false
        });
        return;
      }

      
      if (this.data.showImageCode && this.data.inputCode == null) {

        wx.showModal({
          title: '请输入图形验证码',
          content: "",
          showCancel: false
        });
        return
      }

      var params = {
        method: 'b2c.passport.send_vcode_sms',
        uname: phoneNumber,
        'type': 'signup'
      };
      if (this.data.showImageCode) {
        params.sms_vcode = this.data.inputCode
      }
      const that = this;
      app.request(params, function (data) {
        wx.redirectTo({
          url: '/pages/login/sms_code_fetch?phoneNumber=' + phoneNumber + '&codeURL=' + that.data.codeURL
        })
      }, function () {
        if (that.data.showImageCode) {
          that.tapImageCode()
        }
      }, true, true, true);
  },

  ///获取注册需要的信息
  getRegisterNeedInfo:function(){
    const that = this;
    let params = {
      method:'b2c.passport.signup'
    }
    app.request(params, function (data) {
      if (data.site_sms_valide == 'true') {
        let imageCodeURL = that.data.codeURL + "?t=" + new Date().getTime()
        console.log('imageCOdeURL',imageCodeURL)
        that.getImageCodeRequest(imageCodeURL)
      }
      else {
        that.data.codeURL = ''
      }
    }, function () {
      ///失败回调
    }, true, true, true);
  },

  ///获取图片验证码
  getImageCodeRequest:function(url) {
    const that = this;

    wx.request({
      url: url,
      header: { "Content-Type": "application/json" },
      responseType: 'arraybuffer',
      dataType: "json",
      method: "GET",
      success: function (res) {
        let base64 = wx.arrayBufferToBase64(res.data)
        console.log('base64', base64)

        let src = 'data:image/jpg;base64,' + base64
        console.log('src', src)
        that.setData({
          showImageCode: true,
          imageCodeURL: src
        })
      }
    })
  },
  phoneDidChange:function(event) {
    this.data.phoneNumber = event.detail.value;
    this.changeEnable()
  },
  codeDidChange:function(event) {
    this.data.inputCode = event.detail.value;
    this.changeEnable()
  },
  changeEnable:function(){
    if (this.data.showImageCode) {
      this.setData({
        nextEnable: this.data.phoneNumber != null && this.data.phoneNumber.length > 0 && this.data.inputCode != null && this.data.inputCode.length > 0
      });
    }
    else {
      this.setData({
        nextEnable: this.data.phoneNumber != null && this.data.phoneNumber.length > 0
      });
    }
  },
  ///变更图形验证码
  tapImageCode:function(){

    this.getImageCodeRequest(this.data.codeURL + "?t=" + new Date().getTime() )

  }
})