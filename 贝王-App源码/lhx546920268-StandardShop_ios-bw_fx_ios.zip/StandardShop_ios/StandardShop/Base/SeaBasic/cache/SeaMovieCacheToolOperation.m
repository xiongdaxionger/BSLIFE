//
//  SeaMovieCacheToolOperation.m
//  SuYan
//
//  Created by 罗海雄 on 16/4/25.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import "SeaMovieCacheToolOperation.h"

@implementation SeaMovieCacheToolOperation

- (id)init
{
    self = [super init];
    if(self)
    {
        self.requirements = [NSMutableSet set];
    }
    
    return self;
}

@end


@implementation SeaMovieCacheToolRequirement



@end