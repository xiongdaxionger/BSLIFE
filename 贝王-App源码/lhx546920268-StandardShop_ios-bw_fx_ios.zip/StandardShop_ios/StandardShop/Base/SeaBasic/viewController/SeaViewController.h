//
//  SeaViewController.h

//
//

#import <UIKit/UIKit.h>


/**控制视图的基类
 */
@interface SeaViewController : UIViewController

@end
