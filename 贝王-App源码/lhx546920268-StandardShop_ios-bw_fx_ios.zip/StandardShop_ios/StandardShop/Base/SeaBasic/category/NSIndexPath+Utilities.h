//
//  NSIndexPath+indexPathUtilities.h

//

#import <UIKit/UIKit.h>

@interface NSIndexPath (Utilities)

/**判断是否相等
 */
- (BOOL)isEqual:(id)object;

@end
