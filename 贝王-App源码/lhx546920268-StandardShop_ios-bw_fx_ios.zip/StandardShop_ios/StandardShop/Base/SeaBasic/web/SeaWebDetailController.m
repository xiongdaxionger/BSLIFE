//
//  SeaWebDetailController.m
//  StandardShop
//
//  Created by 罗海雄 on 17/9/12.
//  Copyright © 2017年 qianseit. All rights reserved.
//

#import "SeaWebDetailController.h"

@implementation SeaWebDetailController

//web初始化高
- (instancetype)initWithFrame:(CGRect) frame
{
    self = [super init];
    if(self)
    {
        
    }
    
    return self;
}

- (void)setSuperview:(UIView *)superview
{
    
}

@end
