//
//  WMFoundHomeInfo.m
//  SuYan
//
//  Created by 罗海雄 on 16/4/29.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import "WMFoundHomeInfo.h"

@implementation WMFoundHomeInfo

@end
