//
//  WMFoundHomeViewController.h
//  SuYan
//
//  Created by 罗海雄 on 16/4/29.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import "SeaCollectionViewController.h"

///发现首页
@interface WMFoundHomeViewController : SeaCollectionViewController

@end
