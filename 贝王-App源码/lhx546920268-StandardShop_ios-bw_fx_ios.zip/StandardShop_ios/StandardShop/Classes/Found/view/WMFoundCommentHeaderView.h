//
//  WMFoundCommentHeaderView.h
//  WanShoes
//
//  Created by 罗海雄 on 16/4/7.
//  Copyright (c) 2016年 qianseit. All rights reserved.
//

#import <UIKit/UIKit.h>

///发现评论表头
@interface WMFoundCommentHeaderView : UIView

///发现内容webView
@property(nonatomic,readonly) UIWebView *webView;

@end
