//
//  WMBrandListViewController.h
//  StandardFenXiao
//
//  Created by 罗海雄 on 16/3/31.
//  Copyright (c) 2016年 qianseit. All rights reserved.
//

#import "SeaCollectionViewController.h"

///品牌列表
@interface WMBrandListViewController : SeaCollectionViewController

@end
