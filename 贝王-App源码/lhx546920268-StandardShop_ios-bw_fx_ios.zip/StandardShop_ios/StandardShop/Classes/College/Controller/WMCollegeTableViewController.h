//
//  WMCollegeTableViewController.h
//  WestMailDutyFee
//
//  Created by YUYE on 15/8/29.
//  Copyright (c) 2015年 qianseit. All rights reserved.
//

/**学院列表
 */
@interface WMCollegeTableViewController : SeaTableViewController

@end
