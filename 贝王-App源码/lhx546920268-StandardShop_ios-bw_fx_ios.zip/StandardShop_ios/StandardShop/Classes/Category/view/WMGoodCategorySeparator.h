//
//  WMGoodCategorySeparator.h
//  StandardShop
//
//  Created by 罗海雄 on 16/7/27.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import <UIKit/UIKit.h>

///分割线
@interface WMGoodCategorySeparator : UICollectionReusableView

@end
