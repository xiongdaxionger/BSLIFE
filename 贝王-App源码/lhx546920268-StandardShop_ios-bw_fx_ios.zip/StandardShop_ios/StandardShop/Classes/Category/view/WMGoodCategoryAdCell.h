//
//  WMGoodCategoryAdCell.h
//  StandardShop
//
//  Created by 罗海雄 on 16/6/27.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import <UIKit/UIKit.h>

///商品分类广告cell
@interface WMGoodCategoryAdCell : UICollectionViewCell

///广告图片
@property(nonatomic,readonly) UIImageView *imageView;

@end
