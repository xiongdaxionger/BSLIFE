//
//  WMBillListManagerViewController.h
//  StandardShop
//
//  Created by Hank on 16/11/10.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import "SeaViewController.h"

/**账单的管理控制器
 */
@interface WMBillListManagerViewController : SeaViewController
/**选中的分段控件下标
 */
@property (assign,nonatomic) NSInteger segementIndex;
@end
