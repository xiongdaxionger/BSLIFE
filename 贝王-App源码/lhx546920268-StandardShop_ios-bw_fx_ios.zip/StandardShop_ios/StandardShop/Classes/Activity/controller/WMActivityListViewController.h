//
//  WMActivityListViewController.h
//  StandardShop
//
//  Created by 罗海雄 on 16/6/30.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import "SeaCollectionViewController.h"

///活动列表
@interface WMActivityListViewController : SeaCollectionViewController



@end
