//
//  WMStoreNoneSelectViewCell.h
//  StandardShop
//
//  Created by Hank on 2018/6/11.
//  Copyright © 2018年 qianseit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XTableCellConfigExDelegate.h"

#define WMStoreNoneSelectViewCellIden @"WMStoreNoneSelectViewCellIden"
#define WMStoreNoneSelectViewCellHeight 54.0
///门店自提为空
@interface WMStoreNoneSelectViewCell : UITableViewCell<XTableCellConfigExDelegate>

@end
