//
//  WMTopupAdViewController.h
//  StandardShop
//
//  Created by 罗海雄 on 16/8/17.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import "SeaViewController.h"

///广告充值界面，用来获取是否有充值有礼活动
@interface WMTopupAdViewController : SeaViewController

@end
