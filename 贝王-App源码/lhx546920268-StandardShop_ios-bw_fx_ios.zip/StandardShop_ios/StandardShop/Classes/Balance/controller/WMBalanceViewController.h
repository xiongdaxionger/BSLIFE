//
//  WMBalanceViewController.h
//  StandardShop
//
//  Created by 罗海雄 on 16/7/5.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import "SeaCollectionViewController.h"

///余额、钱包
@interface WMBalanceViewController : SeaCollectionViewController

@end
