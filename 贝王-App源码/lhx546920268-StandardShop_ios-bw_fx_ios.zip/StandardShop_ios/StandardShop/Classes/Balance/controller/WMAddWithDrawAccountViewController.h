//
//  WMAddWithDrawAccountViewController.h
//  StandardFenXiao
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 qianseit. All rights reserved.
//

#import "SeaTableViewController.h"

///添加提现账户
@interface WMAddWithDrawAccountViewController : SeaTableViewController

///图形验证码链接
@property (copy,nonatomic) NSString *codeURL;
@end
