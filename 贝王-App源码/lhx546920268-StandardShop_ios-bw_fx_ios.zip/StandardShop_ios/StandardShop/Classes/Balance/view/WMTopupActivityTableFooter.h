//
//  WMTopupActivityTableFooter.h
//  StandardShop
//
//  Created by 罗海雄 on 16/7/6.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import <UIKit/UIKit.h>

///充值活动底部
@interface WMTopupActivityTableFooter : UIView

///通过充值规则初始化
- (instancetype)initWithRule:(NSString*) rule;

@end
