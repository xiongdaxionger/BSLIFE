//
//  WMCustomerServiceViewController.h
//  StandardShop
//
//  Created by Hank on 16/9/13.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import "SeaCollectionViewController.h"

///客户服务列表
@interface WMCustomerServiceViewController : SeaCollectionViewController

@end
