//
//  WMCollectMoneyInfo.m
//  StandardFenXiao
//
//  Created by 罗海雄 on 16/3/8.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import "WMCollectMoneyInfo.h"

@implementation WMCollectMoneyInfo

@end
