//
//  WMAdviceQuestionView.h
//  StandardShop
//
//  Created by mac on 16/6/3.
//  Copyright © 2016年 qianseit. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WMAdviceQuestionInfo;
/**回复咨询页面咨询问题视图
 */
@interface WMAdviceQuestionView : UIView
/**初始化
 */
- (instancetype)initWithInfo:(WMAdviceQuestionInfo *)info;
@end
